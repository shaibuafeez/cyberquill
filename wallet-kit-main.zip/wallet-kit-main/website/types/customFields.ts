export interface CustomFields {
  walletStandardVersion: string;
}