export enum Token  {
  SUI= 'SUI'
}
