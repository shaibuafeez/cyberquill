# Sui TS SDK Polyfill

This package contains polyfills that are not exported by `@mysten/sui`.
