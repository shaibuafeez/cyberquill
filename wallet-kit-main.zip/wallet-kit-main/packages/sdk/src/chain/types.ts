export type Chain = {
  id: string;
  name: string;
  rpcUrl: string;
};