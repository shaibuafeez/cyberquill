<p align="center"><a href="https://suiet.app">
<img width="480" src="/assets/LogoWithSlogen.png"/>
</a></p>

# Suiet wallet sdk

<a href="https://github.com/wallet-standard/wallet-standard">
  <img src="https://badgen.net/badge/wallet-standard/supported/green" />
</a>

This repo aims at providing easy-to-use utilities for wallet interaction, which is designed in javascript OOP and platform / framework agnostic.